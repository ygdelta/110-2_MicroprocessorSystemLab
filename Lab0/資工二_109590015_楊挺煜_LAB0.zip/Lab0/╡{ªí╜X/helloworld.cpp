#include <iostream>

int main() {
	std::cout << "Hello Ubuntu" << std::endl;
	return 0;
}
